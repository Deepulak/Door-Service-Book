1. Connect the Arduino, Bluetooth Module and servo as shown in the circuit diagram

2. Upload the Arduino Sketch code into the, uhh, Arduino of course. Make sure to unplug the RX pin first before uploading the code or else you will get an error

3. Install the apk file on your Android phone. For those of you who are interested in the Android App code, you can see the app's source code in the Android Studio Project file

4. Open the app and establish a connection with the bluetooth module by pressing the "Connect to Bluetooth Module" button on the app

5. The bluetooth module's light should stop blinking once connection has been established.

6. Enjoy!